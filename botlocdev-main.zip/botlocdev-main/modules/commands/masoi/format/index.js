module.exports = {
	alive: require('./alive.format'),
	diff: require('./diff.format'),
	diff2: require('./diff2.format'),
	notSelf: require('./notSelf.format'),
	validIndex: require('./validIndex.format')
};
